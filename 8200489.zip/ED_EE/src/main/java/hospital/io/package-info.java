/**
 * This package contains the classes that are responsible for reading and writing data to and from files.
 */
package hospital.io;