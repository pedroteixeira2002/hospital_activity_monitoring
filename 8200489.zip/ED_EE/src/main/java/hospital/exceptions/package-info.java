/**
 * This package contains the exception classes that are thrown by the hospital
 * management system.
 */
package hospital.exceptions;