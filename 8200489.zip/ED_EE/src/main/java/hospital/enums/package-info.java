/**
 * This package contains all the enums used in the project.
 */
package hospital.enums;