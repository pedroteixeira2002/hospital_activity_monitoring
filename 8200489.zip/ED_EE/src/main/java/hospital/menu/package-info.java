/**
 * This package contains the classes that are responsible for the menu of the application.
 * It contains the classes that are responsible for reading from the keyboard, displaying the menu and submenus.
 */
package hospital.menu;