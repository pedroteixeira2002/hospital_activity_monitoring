This directory contains the python scratches used to generate the json files for the project
events.json
rooms.json
hospital_map.json
events.json